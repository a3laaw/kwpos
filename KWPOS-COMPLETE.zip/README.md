<div dir="rtl">

# 🏪 KWPOS — نظام نقاط البيع وإدارة الموارد المؤسسية

نظام متكامل لنقاط البيع (POS) وإدارة الموارد المؤسسية (ERP) مصمم خصيصاً للمتاجر الكويتية والخليجية. يدعم اللغتين العربية (RTL) والإنجليزية (LTR)، العملة الكويتية (د.ك)، والقيود المحاسبية المزدوجة التلقائية.

</div>

---

## ✨ المميزات الرئيسية

| الوحدة | الوصف |
|---|---|
| 🛒 **نقاط البيع (POS)** | واجهة كاشير سريعة مع سلة مترقّمة، بحث الهاتف للعميل، بطاقات الفئات، تعليق الفواتير، رسوم التوصيل، تأكيد قبل الاعتماد (Ctrl+Enter) |
| 🧾 **الفواتير** | سجل كامل بترقيم صفحات، طباعة حرارية (80mm) + A4، مرتجعات جزئية مع إشعارات دائن وقاعدة 14 يوماً |
| 🔄 **التبديل (Exchange)** | ربط إلزامي بالفاتورة الأصلية، مسح باركود تلقائي، مقاصة مدمجة (مرتجع + جديد) |
| 📦 **المخزون** | إدارة منتجات متعددة المخازن، باركود تلقائي حسب القسم، حد إعادة الطلب، الجرد الأعمى السريع |
| 🛍 **المشتريات** | أوامر شراء مع اعتماد مدير، مسودة آلية للأصناف الحرجة، محرك تكلفة الوصول (جمارك/شحن) بالمتوسط المرجح |
| 💰 **الأسعار والعروض** | شاشة مستقلة لإدارة الأسعار (تجزئة/جملة/شركات)، عروض ترويجية بـ4 أنماط نطاق، سجل تغييرات غير قابل للتعديل |
| 📊 **التقارير** | تقارير شاملة بفلاتر، مصفوفة أداء الأقسام والأصناف (Tree-View) مع معدل الدوران وأيام الركود |
| 📈 **التحليلات** | تحليلات مبيعات ومخزون تفاعلية |
| 🔢 **المحاسبة** | شجرة حسابات هرمية، قيود مزدوجة تلقائية، مصروفات ورواتب، قائمة الأرباح والخسائر، ميزان المراجعة |
| 🕐 **الورديات** | فتح/إغلاق الوردية، مطابقة النقدية + K-Net + الفيزا، فروقات الدفع الإلكتروني |
| 🔗 **التكاملات** | ربط مع Shopify لاستيراد المنتجات والطلبات |
| 👥 **العملاء** | دليل عملاء مع تصنيف (تجزئة/جملة/شركات) |
| ⚙️ **الإعدادات** | تعدد الدول (12 دولة عربية)، وحدات قياس، فئات برموز |

---

## 🛠 المتطلبات

| المتطلب | الإصدار |
|---|---|
| [Bun](https://bun.sh) | 1.1 أو أحدث |
| Node.js | 18+ (اختياري — Bun يغطي معظم الاحتياجات) |
| متصفح | Chrome / Safari / Firefox (حديث) |

---

## 🚀 خطوات التشغيل

```bash
# 1. استنساخ المستودع
git clone https://github.com/a3laaw/kwpos.git
cd kwpos

# 2. تثبيت الحزم
bun install

# 3. إعداد متغيرات البيئة
cp .env.example .env
# ثم عدّل ملف .env وأضف NEXTAUTH_SECRET (ولّده بـ: openssl rand -base64 32)

# 4. دفع مخطط قاعدة البيانات
bun run db:push

# 5. تهيئة البيانات التجريبية (مستخدمون + منتجات + فئات + مورّدون + حسابات)
curl -X POST http://localhost:3000/api/seed -H "Content-Type: application/json" -d '{"reset": true}'
# أو افتح المتصفح على http://localhost:3000/api/seed بعد تشغيل الخادم

# 6. تشغيل خادم التطوير
bun run dev

# 7. افتح المتصفح
# http://localhost:3000
```

### 🔑 حسابات تجريبية

| الدور | البريد | كلمة المرور | الصلاحيات |
|---|---|---|---|
| مدير النظام | `admin@demo.com` | (انظر الإعدادات) | كل الشاشات |
| موظف مبيعات | `sales@demo.com` | (انظر الإعدادات) | POS، فواتير، تقارير، عملاء، ورديات |
| أمين مخزن | `warehouse@demo.com` | (انظر الإعدادات) | مخزون، مشتريات، مورّدون، جرد أعمى |

---

## 🔐 متغيرات البيئة

أنشئ ملف `.env` في جذر المشروع (استخدم `.env.example` كقالب):

```env
# قاعدة البيانات — PostgreSQL (Supabase)
# الاتصال المجمّع (للتشغيل على Vercel)
DATABASE_URL="postgresql://postgres:PASSWORD@db.PROJECT_REF.supabase.co:6543/postgres?pgbouncer=true&connection_limit=1"
# الاتصال المباشر (لترحيل Prisma فقط)
DIRECT_DATABASE_URL="postgresql://postgres:PASSWORD@db.PROJECT_REF.supabase.co:5432/postgres"

# NextAuth — ولّده بـ: openssl rand -base64 32
NEXTAUTH_SECRET=your-secret-here
NEXTAUTH_URL=http://localhost:3000

# تكامل Shopify (اختياري)
SHOPIFY_STORE_DOMAIN=
SHOPIFY_ACCESS_TOKEN=
```

> ⚠️ **تحذير أمني:** لا ترفع ملف `.env` إلى Git أبداً — يحتوي على أسرار قاعدة البيانات. الملف مُستبعد في `.gitignore`. في الإنتاج، عيّن متغيرات البيئة من لوحة تحكم Vercel (Project Settings → Environment Variables) وليس في `vercel.json`.

---

## 📁 هيكل المجلدات

```
kwpos/
├── prisma/
│   └── schema.prisma          # مخطط قاعدة البيانات (39 نموذج)
├── src/
│   ├── app/                   # صفحات App Router + API routes
│   │   ├── api/               # 111 نقطة API (مبيعات، مشتريات، تقارير، ...)
│   │   ├── layout.tsx         # تخطيط الجذر (dir/lang من i18n)
│   │   └── page.tsx           # الصفحة الرئيسية (تسجيل دخول أو التطبيق)
│   ├── components/            # مكونات الواجهة
│   │   ├── sales/             # POS، فواتير، تبديل، مرتجع
│   │   ├── inventory/         # مخزون، نموذج منتج، مخازن
│   │   ├── purchases/         # مشتريات، اعتماد، مورّدون
│   │   ├── reports/           # تقارير + مصفوفة الأداء
│   │   ├── pricing/           # محرك الأسعار والعروض
│   │   ├── shift/             # الورديات وتصفير الصندوق
│   │   ├── spotcheck/         # الجرد الأعمى
│   │   ├── accounting/        # محاسبة، قيود، مصروفات
│   │   ├── dashboard/         # لوحة التحكم
│   │   ├── customers/         # دليل العملاء
│   │   ├── analytics/         # تحليلات
│   │   ├── settings/          # إعدادات (دولة، عملة، وحدات، فئات)
│   │   ├── integrations/      # تكامل Shopify
│   │   ├── shared/            # مكونات مشتركة (تأكيد، Excel، رفع صور)
│   │   └── ui/                # مكونات shadcn/ui
│   ├── lib/                   # مكتبات ومساعدات
│   │   ├── i18n.ts            # قاموس الترجمة (1374 مفتاح × لغتين)
│   │   ├── pricing.ts         # محرك حساب السعر الفعلي + العروض
│   │   ├── landed-cost.ts     # محرك تكلفة الوصول (متوسط مرجح)
│   │   ├── journal.ts         # توليد القيود المحاسبية
│   │   ├── print.ts           # طباعة الإيصالات (حراري + A4 + باركود)
│   │   ├── barcode.ts         # توليد الباركود التلقائي
│   │   ├── countries.ts       # إعدادات 12 دولة عربية
│   │   ├── db.ts              # عميل Prisma
│   │   ├── auth.ts            # إعدادات NextAuth
│   │   └── format.ts          # تنسيق العملة والتواريخ
│   └── hooks/
│       └── use-api.ts         # خطافات TanStack Query لكل API
├── public/                    # ملفات عامة (شعار، أيقونات)
├── .env.example               # قالب متغيرات البيئة
├── .gitignore
├── package.json
├── tsconfig.json
└── next.config.ts
```

---

## 📜 الأوامر الشائعة

| الأمر | الوصف |
|---|---|
| `bun run dev` | تشغيل خادم التطوير (http://localhost:3000) |
| `bun run build` | بناء نسخة الإنتاج |
| `bun run start` | تشغيل خادم الإنتاج |
| `bun run lint` | فحص جودة الكود (ESLint) |
| `bun run db:push` | دفع مخطط Prisma إلى قاعدة البيانات |
| `bun run db:generate` | توليد عميل Prisma |
| `bun run db:migrate` | إنشاء ترحيل (migration) |
| `bun run db:reset` | إعادة تعيين قاعدة البيانات |
| `bun run test` | تشغيل اختبارات Vitest مرة واحدة |
| `bun run test:watch` | تشغيل الاختبارات في وضع المراقبة |
| `bun run test:ui` | تشغيل واجهة Vitest UI في المتصفح |

---

## 🧪 الاختبارات (Vitest)

يحتوي المشروع على 9 ملفات اختبار (100 اختبار فرعي) لأهمّ منطق الأعمال:

| الملف | السيناريو |
|---|---|
| `tests/sale-stock-warehouses.test.ts` | بيع POS: رفض النقص في مخزن محدّد حتى لو كان المجموع الكافي |
| `tests/sale-concurrency.test.ts` | بيع متزامن للوحدة الأخيرة — نجاح واحد فقط |
| `tests/journal-rollback.test.ts` | فشل القيد المحاسبي داخل المعاملة يلغي البيع بالكامل |
| `tests/supplier-payment-limit.test.ts` | حدّ سداد المورّد + تجاوز إداري |
| `tests/shift-expected-totals.test.ts` | إغلاق الوردية: التوقع يُحسب للمستخدم وحده |
| `tests/vat-report.test.ts` | تقرير ض.ق.م: استلام أمر شراء vs فاتورة مرحيّلة — بدون ازدواج |
| `tests/bundles-compositions.test.ts` | حسابات الباقات/التركيبات: التكلفة، الربح، تقشير حقول التكلفة حسب الدور |
| `tests/pricing-promotions.test.ts` | محرك الأسعار: سعر الفئة، نطاقات العروض، السعر الفعلي |
| `tests/excel-import-export.test.ts` | دوال Excel: تحليل الملف، التصدير، القالب، التحقق من الامتدادات والأعمدة |

### التشغيل

```bash
# تشغيل كل الاختبارات مرة واحدة (يستخدم SQLite محلي — لا يلمس Supabase)
bun run test

# وضع المراقبة (إعادة تشغيل عند التغيير)
bun run test:watch

# واجهة Vitest UI في المتصفح
bun run test:ui
```

### تفاصيل تقنية

- **قاعدة بيانات الاختبار**: ملف SQLite في `prisma/test.db` — يُعاد إنشاؤه قبل كل تشغيل.
- **مخطط منفصل**: `prisma/schema.test.prisma` (SQLite) — لا يتداخل مع مخطط PostgreSQL الإنتاجي.
- **عميل Prisma منفصل**: يُولَّد إلى `node_modules/.prisma/test-client`.
- **العزل**: `tests/setup.ts` يُعيّن `globalThis.prisma` ليستخدمه `@/lib/db` بدلاً من عميل Postgres.
- **التشغيل التسلسلي**: الملفات تعمل واحدة تلو الأخرى (SQLite لا يدعم الكتابة المتوازية على نفس الملف).
- **محاكاة الجلسة**: يُستبدل `getCurrentUser` في كل ملف اختبار عبر `vi.mock("@/lib/session", ...)`.

انظر `tests/README.md` للتفاصيل الكاملة.


---

## 🌍 الدول المدعومة

| الدولة | العملة | الرمز | الخانات العشرية |
|---|---|---|---|
| 🇰🇼 الكويت | دينار كويتي | د.ك | 3 |
| 🇸🇦 السعودية | ريال سعودي | ر.س | 2 |
| 🇦🇪 الإمارات | درهم إماراتي | د.إ | 2 |
| 🇶🇦 قطر | ريال قطري | ر.ق | 2 |
| 🇧🇭 البحرين | دينار بحريني | د.ب | 3 |
| 🇴🇲 عُمان | ريال عماني | ر.ع | 3 |
| 🇪🇬 مصر | جنيه مصري | ج.م | 2 |
| 🇯🇴 الأردن | دينار أردني | د.أ | 3 |
| 🇲🇦 المغرب | درهم مغربي | د.م | 2 |
| 🇮🇶 العراق | دينار عراقي | د.ع | 3 |
| 🇩🇿 الجزائر | دينار جزائري | د.ج | 2 |
| 🇹🇳 تونس | دينار تونسي | د.ت | 3 |

---

## 🏗 البنية التقنية

| الطبقة | التقنية |
|---|---|
| الإطار | Next.js 16 (App Router + Turbopack) |
| اللغة | TypeScript 5 |
| الواجهة | React 19 + Tailwind CSS 4 + shadcn/ui (Radix UI) |
| قاعدة البيانات | Prisma ORM + PostgreSQL (Supabase) |
| المصادقة | NextAuth.js v4 (JWT sessions) |
| إدارة الحالة | TanStack Query (server) + Zustand (client UI) |
| الرسوم البيانية | Recharts |
| الطباعة | نوافذ طباعة مخصصة (80mm + A4 + باركود) |
| i18n | نظام مخصص (1374 مفتاح × عربي/إنجليزي) |
| الحزم | Bun |

---

## 🔒 الأمان والرقابة

- **نوافذ التأكيد**: كل عمليات الحذف/التعديل/الإلغاء تتطلب نافذة تأكيد تحذيرية.
- **حماية لوحة المفاتيح**: لا يُعتمد البيع بضغطة Enter مفردة — فقط Ctrl+Enter أو نقر.
- **سجل تغييرات الأسعار**: غير قابل للتعديل أو الحذف (immutable audit log).
- **الجرد الأعمى**: لا يُكشف الرصيد الدفتري إلا بعد إدخال الكمية الفعلية.
- **تأمين التبديل**: ربط إلزامي برقم الفاتورة الأصلية + قاعدة 14 يوماً + التحقق من الكمية المتبقية.
- **صلاحيات الأدوار**: ADMIN / SALES / WAREHOUSE لكل منها صلاحيات عرض وتعديل محددة.

---

## 📄 الترخيص

هذا المشروع مملوك للمستخدم [a3laaw](https://github.com/a3laaw). جميع الحقوق محفوظة.

---

## 🤝 المساهمة

للمساهمة في المشروع:

1. افتح Issue لمناقشة التغيير المطلوب.
2. أنشئ فرعاً جديداً (`git checkout -b feature/amazing-feature`).
3. التزم بمعايير الكود (`bun run lint` يجب أن يكون نظيفاً).
4. افتح Pull Request.

---

<div dir="rtl">

صُنع بـ ❤️ للمشاريع الصغيرة الكويتية

---

## 🔄 الانتقال إلى Supabase (PostgreSQL)

### لماذا Supabase؟
- نسخ احتياطي تلقائي يومي
- جاهزية للفروع المستقبلية
- أمان ودعم جيد لـ Prisma

### الخطوات

#### 1. إنشاء مشروع Supabase
1. اذهب إلى https://supabase.com → سجّل بـ GitHub
2. **New Project** → اسمه `kwpos-production`
3. المنطقة: **Frankfurt (eu-central-1)** (أقرب للكويت)
4. احفظ كلمة مرور قاعدة البيانات

#### 2. نسخ Connection Strings
من **Project Settings → Database → Connection string**:
- **Direct URL** (للـ migrations): `postgresql://postgres:PASSWORD@db.HOST.supabase.co:5432/postgres`
- **Pooled URL** (للتشغيل): `postgresql://postgres:PASSWORD@db.HOST.supabase.co:6543/postgres?pgbouncer=true&connection_limit=1`

#### 3. تحديث `.env`
```env
DATABASE_URL="postgresql://postgres:PASSWORD@db.HOST.supabase.co:6543/postgres?pgbouncer=true&connection_limit=1"
DIRECT_DATABASE_URL="postgresql://postgres:PASSWORD@db.HOST.supabase.co:5432/postgres"
```

#### 4. تحديث `schema.prisma`
```prisma
datasource db {
  provider  = "postgresql"
  url       = env("DATABASE_URL")
  directUrl = env("DIRECT_DATABASE_URL")
}
```

#### 5. إنشاء الجداول
```bash
bun run db:push
```

#### 6. نقل البيانات من SQLite
```bash
bun scripts/migrate-sqlite-to-supabase.ts
```

#### 7. اختبار التطبيق
```bash
bun run dev
# سجّل الدخول → POS → بيع → تحقق من الفاتورة
```

#### 8. إنشاء Migration رسمي
```bash
bun run db:migrate --name init_supabase
```

#### 9. تأمين RLS (اختياري)
في Supabase Dashboard → **Authentication → Policies** → فعّل RLS على الجداول الحساسة.

</div>
