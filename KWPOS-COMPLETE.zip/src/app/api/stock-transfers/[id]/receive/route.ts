import { NextRequest, NextResponse } from "next/server"
import { db, updateProductQuantityFromStockItems } from "@/lib/db"
import { getCurrentUser, hasRole } from "@/lib/session"
import { logAuditEvent } from "@/lib/audit"
import type { Role } from "@/lib/types"

export const dynamic = "force-dynamic"

/**
 * POST /api/stock-transfers/[id]/receive — receive a transfer (Transfer In).
 * Adds quantities to destination warehouse (StockItem + Product aggregate),
 * marks as RECEIVED. ADMIN/WAREHOUSE only.
 */
export async function POST(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getCurrentUser()
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 })
  if (!hasRole(user.role, ["OWNER", "ADMIN", "WAREHOUSE" as Role])) {
    return NextResponse.json({ error: "forbidden" }, { status: 403 })
  }

  const { id } = await params
  const transfer = await db.stockTransfer.findUnique({
    where: { id },
    include: { items: true, fromWarehouse: true, toWarehouse: true },
  })
  if (!transfer) return NextResponse.json({ error: "not-found" }, { status: 404 })
  if (transfer.status === "RECEIVED") {
    return NextResponse.json({ error: "already-received" }, { status: 409 })
  }

  const updated = await db.$transaction(async (tx) => {
    // Add to destination warehouse (StockItem only — Product.quantity is
    // recomputed from StockItems as the derived aggregate).
    // Note: no SELECT FOR UPDATE — incompatible with pgbouncer on Supabase.
    for (const it of transfer.items) {
      await tx.stockItem.upsert({
        where: {
          productId_warehouseId: {
            productId: it.productId,
            warehouseId: transfer.toWarehouseId,
          },
        },
        update: { quantity: { increment: it.quantity } },
        create: {
          productId: it.productId,
          warehouseId: transfer.toWarehouseId,
          quantity: it.quantity,
        },
      })
      // Product.quantity sync is deferred to post-commit (see below).
    }
    const updated = await tx.stockTransfer.update({
      where: { id },
      data: {
        status: "RECEIVED",
        receivedById: user.id,
        receivedAt: new Date(),
      },
      include: {
        items: { include: { product: true } },
        fromWarehouse: true,
        toWarehouse: true,
        createdBy: true,
        receivedBy: true,
      },
    })

    // ── Audit log (inside tx — atomic) ──
    await logAuditEvent({
      tx,
      userId: user.id,
      userName: user.name,
      action: "STOCK_TRANSFER_RECEIVED",
      description: `استلام تحويل ${updated.transferNo}`,
    })

    return updated
  }, {
    timeout: 15000,
    maxWait: 5000,
  })

  // Post-commit: sync Product.quantity OUTSIDE the transaction.
  try {
    const pids = Array.from(new Set(transfer.items.map((it: any) => it.productId)))
    for (const pid of pids) {
      await updateProductQuantityFromStockItems(db, pid)
    }
  } catch {
    // Non-fatal: transfer is received, StockItem is correct.
  }

  return NextResponse.json({
    id: updated.id,
    transferNo: updated.transferNo,
    status: updated.status,
    receivedAt: String(updated.receivedAt),
  })
}
