<div dir="rtl">

# 📚 فهرس وثائق نظام KWPOS

هذا الفهرس يجمّع كل ملفات التوثيق في مجلّد `docs/`. الوثائق مرتَّبة من العام إلى الخاص: تبدأ بنظرة عامة، ثم الأدوار والصلاحيات والتخطيط، ثم تنتقل إلى كل وحدة من وحدات النظام.

> **الحالة:** كل الوثائق من `00` إلى `20` جاهزة بالكامل في هذا الإصدار. كل وثيقة مكتوبة بالعربية الفصحى المبسّطة لغير المختصين، مع جداول وأمثلة عملية مأخوذة مباشرة من الكود.

---

## 🗂 جدول الوثائق

| # | الملف | الموضوع | الحالة |
|---|---|---|---|
| 00 | [`00-overview.md`](./00-overview.md) | نظرة عامة على النظام: ما هو KWPOS، أهدافه، مستخدموه، اللغات والعملات، سير العمل، البنية التقنية | ✅ جاهزة |
| 01 | [`01-roles-permissions.md`](./01-roles-permissions.md) | الأدوار السبعة (OWNER, ADMIN, MANAGER, ACCOUNTANT, WAREHOUSE, SALES, CASHIER) وصلاحياتها بالتفصيل مع جداول مقارنة | ✅ جاهزة |
| 02 | [`02-navigation-layout.md`](./02-navigation-layout.md) | شاشة الدخول، الشريط الجانبي، الشريط العلوي، لوحة التحكم، البحث ⌘K، التنبيهات، تبديل اللغة، عرض العملة | ✅ جاهزة |
| 03 | [`03-pos.md`](./03-pos.md) | شاشة نقاط البيع (POS): عناصر الشاشة، كل زر ووظيفته، دورة البيع الكاملة، الوضع السريع، الفواتير المعلّقة، الأخطاء المحتملة | ✅ جاهزة |
| 04 | [`04-sales-invoices-refunds-cancel.md`](./04-sales-invoices-refunds-cancel.md) | الفواتير: البحث، التفاصيل، الطباعة، المرتجع الجزئي، الإلغاء الكامل، الفرق بين الإلغاء والحذف، إشعار دائن، عكس المخزون والقيد | ✅ جاهزة |
| 05 | [`05-inventory.md`](./05-inventory.md) | المخزون: المنتجات، نموذج الإضافة/التعديل، التصنيفات (أب/ابن)، الوحدات، المخازن، حركة المخزون، الجرد الكامل، الجرد الأعمى، التحويلات | ✅ جاهزة |
| 06 | [`06-purchases.md`](./06-purchases.md) | المشتريات: الموردون (محلي/خارجي)، أوامر الشراء، فواتير الشراء (طريقة الدفع، تكلفة الوصول)، مرتجعات المشتريات | ✅ جاهزة |
| 07 | [`07-suppliers-payments.md`](./07-suppliers-payments.md) | سداد الموردين: إضافة دفعة، طرق الدفع، منع السداد الزائد، كشف حساب المورد، حذف الدفعة وتأثيره | ✅ جاهزة |
| 08 | [`08-customers.md`](./08-customers.md) | العملاء: الإضافة/التعديل، النوع (تجزئة/جملة/شركات)، نقاط الولاء، كشف الحساب، العميل النقدي | ✅ جاهزة |
| 09 | [`09-pricing-promotions.md`](./09-pricing-promotions.md) | التسعير: محرك التسعير، الأسعار الثلاثة، العروض (نسبة/مبلغ، نطاقات)، سجل تغييرات الأسعار، منع التلاعب بالسعر | ✅ جاهزة |
| 10 | [`10-bundles-compositions.md`](./10-bundles-compositions.md) | الباقات والتركيبات: الفرق، نموذج المصنع الصغير، إنشاء منتج تلقائياً، مبلغ الربح، الإنتاج، استهلاك المكونات | ✅ جاهزة |
| 11 | [`11-accounting.md`](./11-accounting.md) | المحاسبة: شجرة الحسابات، القيود اليومية، المصروفات، التقارير المالية (ميزان المراجعة، قائمة الدخل، الميزانية، الأستاذ العام، VAT) | ✅ جاهزة |
| 12 | [`12-shifts.md`](./12-shifts.md) | الورديات: فتح/إغلاق، الرصيد الافتتاحي، النقد المتوقع، K-Net، Visa، الفروقات، الإغلاق الأعمى، اعتماد المدير | ✅ جاهزة |
| 13 | [`13-reports-analytics.md`](./13-reports-analytics.md) | التقارير والتحليلات: تقارير المبيعات/المخزون/المشتريات، مصفوفة الأداء، لوحات التحكم (عامة/مدير/مالك)، مؤشرات الأداء | ✅ جاهزة |
| 14 | [`14-settings-users.md`](./14-settings-users.md) | الإعدادات: الدولة والعملة، إدارة المستخدمين، كلمة المرور، الوضع السريع، ربط المستخدم بمخزن، التصنيفات، الوحدات، المخازن | ✅ جاهزة |
| 15 | [`15-integrations-shopify.md`](./15-integrations-shopify.md) | تكامل Shopify: استيراد الطلبات، مزامنة المنتجات، حالة الاتصال، متغيرات البيئة المطلوبة، الأخطاء | ✅ جاهزة |
| 16 | [`16-excel-import-export.md`](./16-excel-import-export.md) | Excel: تصدير المنتجات/العملاء/المبيعات/الموردين/القيود، استيراد المنتجات/العملاء، القالب، التصنيفات المتداخلة، روابط الصور | ✅ جاهزة |
| 17 | [`17-api-reference.md`](./17-api-reference.md) | مرجع API مبسّط: جدول لكل مسار مهم (المسار، الطريقة، الوظيفة، الصلاحيات، المدخلات، المخرجات) | ✅ جاهزة |
| 18 | [`18-workflows.md`](./18-workflows.md) | سيناريوهات عملية: بيع، إضافة منتج، شراء بضاعة، مرتجع، إلغاء، جرد، إغلاق وردية، تركيبة، سداد مورد، عرض ترويجي | ✅ جاهزة |
| 19 | [`19-errors-troubleshooting.md`](./19-errors-troubleshooting.md) | الأخطاء والتنبيهات: لكل خطأ — أين يظهر، سببه، كيف يحله المستخدم (40+ رمز خطأ) | ✅ جاهزة |
| 20 | [`20-deployment-technical-notes.md`](./20-deployment-technical-notes.md) | ملاحظات تقنية للإدارة: Supabase، Vercel، Prisma، NextAuth، متغيرات البيئة، النشر، النسخ الاحتياطي، المخاطر التشغيلية | ✅ جاهزة |

---

## 🔎 كيف تجد ما تبحث عنه؟

| إذا كنت تبحث عن… | ابدأ من |
|---|---|
| ما هو هذا النظام؟ | [`00-overview.md`](./00-overview.md) |
| صلاحيات موظف معيّن | [`01-roles-permissions.md`](./01-roles-permissions.md) |
| كيف أفتح شاشة كذا؟ | [`02-navigation-layout.md`](./02-navigation-layout.md) |
| كيف أبيع في POS؟ | [`03-pos.md`](./03-pos.md) |
| كيف أطبع فاتورة؟ | [`04-sales-invoices-refunds-cancel.md`](./04-sales-invoices-refunds-cancel.md) |
| كيف أضيف منتجاً؟ | [`05-inventory.md`](./05-inventory.md) |
| كيف أنشئ أمر شراء؟ | [`06-purchases.md`](./06-purchases.md) |
| كيف أسدد لمورد؟ | [`07-suppliers-payments.md`](./07-suppliers-payments.md) |
| كيف أُغلق وردية؟ | [`12-shifts.md`](./12-shifts.md) |
| كيف أُنشئ قيداً يدوياً؟ | [`11-accounting.md`](./11-accounting.md) |
| كيف أُنشئ تركيبة؟ | [`10-bundles-compositions.md`](./10-bundles-compositions.md) |
| كيف أبدّل الدولة/العملة؟ | [`14-settings-users.md`](./14-settings-users.md) |
| ما معنى هذا الخطأ؟ | [`19-errors-troubleshooting.md`](./19-errors-troubleshooting.md) |
| كيف أنشر النظام؟ | [`20-deployment-technical-notes.md`](./20-deployment-technical-notes.md) |
| ما مسارات API المتاحة؟ | [`17-api-reference.md`](./17-api-reference.md) |
| سيناريو عملي شامل؟ | [`18-workflows.md`](./18-workflows.md) |

---

## 🧭 المصادر البرمجية المرجعية

كل وثيقة تشير في متنها إلى الملفات المصدرية التي اعتمدت عليها. أهمها:

| الملف | دوره |
|---|---|
| `prisma/schema.prisma` | نماذج البيانات (35+ نموذج) |
| `src/lib/types.ts` | تعريف أنواع TypeScript + `Role` + `AppView` |
| `src/lib/session.ts` | `ROLE_PERMISSIONS` (صلاحيات العرض) |
| `src/lib/permissions.ts` | صلاحيات الإجراءات والحقول (`canDelete`, `canSeeCost`, `canSeeFinancials`, ...) |
| `src/lib/auth.ts` | إعدادات NextAuth + منطق تسجيل الدخول |
| `src/lib/countries.ts` | إعدادات 12 دولة عربية |
| `src/lib/settings.ts` | قراءة/كتابة الدولة الفعّالة |
| `src/lib/db.ts` | اتصال Prisma + إدارة الاتصال على Vercel/Supabase |
| `src/components/nav-config.ts` | عناصر القائمة الجانبية |
| `src/components/module-nav-config.ts` | التبويبات الفرعية لكل وحدة (MegaMenu) |
| `src/components/app-shell.tsx` | التخطيط العام بعد الدخول |
| `src/components/auth/login-screen.tsx` | شاشة الدخول |
| `src/components/shared/global-search.tsx` | البحث الشامل ⌘K |
| `src/components/shared/notifications-bell.tsx` | جرس التنبيهات |
| `src/components/i18n-context.tsx` | نظام اللغتين (عربي/إنجليزي) |
| `src/components/currency-context.tsx` | تنسيق العملة والتواريخ |
| `src/app/page.tsx` | الصفحة الجذر (auto-bootstrap admin) |
| `src/app/api/` | كل مسارات API |
| `README.md` | دليل المشروع الأساسي |
| `DEPLOY.md` | دليل النشر على Supabase + Vercel |

---

## 📝 قواعد الكتابة المعتمدة في هذه الوثائق

1. **اللغة:** عربية فصحى مبسّطة لغير المختصين.
2. **الاتجاه:** كل ملف ملفوف بـ `<div dir="rtl">…</div>` ليظهر بشكل صحيح في GitHub وغيره.
3. **الجداول:** يُعتمد الجدول بكثرة لأنه أوضح للمقارنات.
4. **الإشارة للكود:** يُذكر اسم الملف المصدر بين backticks (مثل `src/lib/permissions.ts`).
5. **عدم الاختلاق:** أي ميزة لا تظهر في الكود تُذكر صراحةً بعبارة «لم يظهر في الكود».
6. **الهدف:** دليل تدريبي عملي للموظفين، لا مرجع برمجي للمطوّرين.

---

## 📚 وثائق التنفيذية والإدارية (في جذر المشروع)

إضافةً إلى الوثائق التقنية أعلاه، يتوفّر في جذر المشروع ملفان عمليان موجّهان للإدارة:

| الملف | الجمهور | الاستخدام |
|---|---|---|
| [`KWPOS_OPERATION_MANUAL.md`](../KWPOS_OPERATION_MANUAL.md) | المالك / المدير / مدير الوردية | دليل تشغيل عملي مُرتَّب زمنياً (يومي → أسبوعي → شهري) + إجراءات حرجة + طوارئ + قوالب طباعة يدوية |
| [`KWPOS_PRESENTATION.md`](../KWPOS_PRESENTATION.md) | المستثمرون / الملاك / الفروع الجديدة | عرض تقديمي تنفيذي 22 شريحة بصيغة Markdown (عرض مباشر أو طباعة) |
| [`KWPOS_USER_MANUAL.md`](../KWPOS_USER_MANUAL.md) | كل المستخدمين | دليل مستخدم شامل مختصر (22 قسم) |
| [`SYSTEM_DOCUMENTATION.md`](../SYSTEM_DOCUMENTATION.md) | المطورون | توثيق تقني تفصيلي للنظام |
| [`DEPLOY.md`](../DEPLOY.md) | مدير النظام | دليل النشر على Supabase + Vercel |

> 💡 **كيف تختار؟**  
> - تريد **معرفة ماذا تفعل الآن** → `KWPOS_OPERATION_MANUAL.md`  
> - تريد **عرض النظام لشخص آخر** → `KWPOS_PRESENTATION.md`  
> - تريد **مرجعاً سريعاً لميزة ما** → `KWPOS_USER_MANUAL.md`  
> - تريد **تفاصيل تقنية** → ابدأ من فهرس `docs/` ثم `SYSTEM_DOCUMENTATION.md`

---

## 🚀 للبدء سريعاً

1. اقرأ [`00-overview.md`](./00-overview.md) لفهم النظام ككل.
2. اقرأ [`01-roles-permissions.md`](./01-roles-permissions.md) لتعرف ما يستطيع دورك رؤيته.
3. اقرأ [`02-navigation-layout.md`](./02-navigation-layout.md) لتتعوّد على الواجهة.
4. انتقل إلى الوثيقة الخاصة بالوحدة التي تعمل فيها (POS، المخزون، المحاسبة...).
5. للسيناريوهات العملية الشاملة، راجع [`18-workflows.md`](./18-workflows.md).
6. لأي خطأ تراه، راجع [`19-errors-troubleshooting.md`](./19-errors-troubleshooting.md).
7. للتشغيل اليومي خطوة بخطوة، راجع [`../KWPOS_OPERATION_MANUAL.md`](../KWPOS_OPERATION_MANUAL.md).
8. لعرض النظام على جهة خارجية، راجع [`../KWPOS_PRESENTATION.md`](../KWPOS_PRESENTATION.md).

---

</div>
